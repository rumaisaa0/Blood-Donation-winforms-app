﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class transfusion : UserControl
    {
        public transfusion()
        {
            InitializeComponent();
        }

        private void lbldate_Click(object sender, EventArgs e)
        {
            dtpappointmentDate.Select();
            SendKeys.Send("%{DOWN}");
        }

        private void dtpappointmentDate_ValueChanged(object sender, EventArgs e)
        {
            lbldate.Text = dtpappointmentDate.Text;

        }

        private void transfusion_Load(object sender, EventArgs e)
        {
            lbldate.Text = dtpappointmentDate.Text;
        }
    }
}
