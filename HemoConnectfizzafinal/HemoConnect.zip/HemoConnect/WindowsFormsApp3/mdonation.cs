﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class mdonation : UserControl
    {
        SqlConnection connect
          = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Rizwan Moosa Saya\Documents\blooddonation.mdf;Integrated Security=True;Connect Timeout=30");
        public mdonation()
        {
            InitializeComponent();
            loaddata();
        }

        private void lbldate_Click(object sender, EventArgs e)
        {
            dtpappointmentDate.Select();
            SendKeys.Send("%{DOWN}");
        }

        private void dtpappointmentDate_ValueChanged(object sender, EventArgs e)
        {
            lbldate.Text = dtpappointmentDate.Text;

        }

        private void mdonation_Load(object sender, EventArgs e)
        {
            lbldate.Text = dtpappointmentDate.Text;
            PopulateTimeSlots();
        }
        private void PopulateTimeSlots()
        {
            // Clear existing items
            comboBox1.Items.Clear();

            // Add time slots from 9 AM to 5 PM
            for (int hour = 9; hour <= 17; hour++)
            {
                comboBox1.Items.Add(hour.ToString("00") + ":00"); // Add hour with minutes
                comboBox1.Items.Add(hour.ToString("00") + ":30"); // Add hour with half past
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void loaddata()
        {
            
            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();
                    // TO CHECK IF THE USER IS EXISTING ALREADY
                    string selectrows = "SELECT appointmentid, appointmentdate, confirmationstatus FROM appointments " +
                        "where confirmationstatus='confirmed'";

                    using (SqlCommand cmd = new SqlCommand(selectrows, connect))
                    {

                        // Create a DataTable to hold the data
                        DataTable dataTable = new DataTable();
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        // Fill the DataTable with data from SQL
                        adapter.Fill(dataTable);
                        dgvappointment.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex
                , "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    dgvappointment.Columns[0].HeaderText = "AppID";
                    dgvappointment.Columns[1].HeaderText = "Date";
                    dgvappointment.Columns[2].HeaderText = "Status";
                    connect.Close();
                }
            }

        }
    }
}
