﻿namespace WindowsFormsApp3
{
    partial class donors
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(donors));
            this.l_wrongusername = new System.Windows.Forms.Label();
            this.l_emptyname = new System.Windows.Forms.Label();
            this.underpassword = new System.Windows.Forms.Panel();
            this.login_passwordtxtbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.underusername = new System.Windows.Forms.Panel();
            this.login_username = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.l_contact = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.undercontact = new System.Windows.Forms.Panel();
            this.contactbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.l_bloodgroup = new System.Windows.Forms.Label();
            this.underbloodgroup = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bloodgroupbox = new System.Windows.Forms.ComboBox();
            this.l_email = new System.Windows.Forms.Label();
            this.dataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.chartAp = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartABp = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartABn = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartAn = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartBn = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartOn = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartOp = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartBp = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.updatedonorbtn = new System.Windows.Forms.Button();
            this.adddonorbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartABp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartABn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartBn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartOn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartOp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartBp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // l_wrongusername
            // 
            this.l_wrongusername.AutoSize = true;
            this.l_wrongusername.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_wrongusername.Location = new System.Drawing.Point(36, 215);
            this.l_wrongusername.Name = "l_wrongusername";
            this.l_wrongusername.Size = new System.Drawing.Size(224, 21);
            this.l_wrongusername.TabIndex = 50;
            this.l_wrongusername.Text = "This user ID does not exist.";
            this.l_wrongusername.Visible = false;
            // 
            // l_emptyname
            // 
            this.l_emptyname.AutoSize = true;
            this.l_emptyname.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_emptyname.Location = new System.Drawing.Point(33, 215);
            this.l_emptyname.Name = "l_emptyname";
            this.l_emptyname.Size = new System.Drawing.Size(245, 21);
            this.l_emptyname.TabIndex = 47;
            this.l_emptyname.Text = "Username cannot be empty";
            this.l_emptyname.Visible = false;
            // 
            // underpassword
            // 
            this.underpassword.BackColor = System.Drawing.Color.Gray;
            this.underpassword.Location = new System.Drawing.Point(37, 322);
            this.underpassword.Name = "underpassword";
            this.underpassword.Size = new System.Drawing.Size(400, 3);
            this.underpassword.TabIndex = 44;
            // 
            // login_passwordtxtbox
            // 
            this.login_passwordtxtbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.login_passwordtxtbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.login_passwordtxtbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_passwordtxtbox.ForeColor = System.Drawing.Color.Gray;
            this.login_passwordtxtbox.Location = new System.Drawing.Point(37, 291);
            this.login_passwordtxtbox.Name = "login_passwordtxtbox";
            this.login_passwordtxtbox.Size = new System.Drawing.Size(314, 25);
            this.login_passwordtxtbox.TabIndex = 43;
            this.login_passwordtxtbox.Text = "e.g: hello123@gmail.com";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(32, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 27);
            this.label3.TabIndex = 42;
            this.label3.Text = "Email:";
            // 
            // underusername
            // 
            this.underusername.BackColor = System.Drawing.Color.Gray;
            this.underusername.Location = new System.Drawing.Point(33, 209);
            this.underusername.Name = "underusername";
            this.underusername.Size = new System.Drawing.Size(400, 3);
            this.underusername.TabIndex = 41;
            // 
            // login_username
            // 
            this.login_username.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.login_username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.login_username.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_username.ForeColor = System.Drawing.Color.Gray;
            this.login_username.Location = new System.Drawing.Point(33, 178);
            this.login_username.Name = "login_username";
            this.login_username.Size = new System.Drawing.Size(314, 25);
            this.login_username.TabIndex = 40;
            this.login_username.Text = "e.g: 1002";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 27);
            this.label2.TabIndex = 39;
            this.label2.Text = "User ID:";
            // 
            // l_contact
            // 
            this.l_contact.AutoSize = true;
            this.l_contact.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_contact.Location = new System.Drawing.Point(40, 446);
            this.l_contact.Name = "l_contact";
            this.l_contact.Size = new System.Drawing.Size(240, 21);
            this.l_contact.TabIndex = 56;
            this.l_contact.Text = "Enter valid contact number";
            this.l_contact.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 446);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(245, 21);
            this.label4.TabIndex = 55;
            this.label4.Text = "Username cannot be empty";
            this.label4.Visible = false;
            // 
            // undercontact
            // 
            this.undercontact.BackColor = System.Drawing.Color.Gray;
            this.undercontact.Location = new System.Drawing.Point(37, 440);
            this.undercontact.Name = "undercontact";
            this.undercontact.Size = new System.Drawing.Size(400, 3);
            this.undercontact.TabIndex = 54;
            // 
            // contactbox
            // 
            this.contactbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.contactbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.contactbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactbox.ForeColor = System.Drawing.Color.Gray;
            this.contactbox.Location = new System.Drawing.Point(37, 409);
            this.contactbox.Name = "contactbox";
            this.contactbox.Size = new System.Drawing.Size(314, 25);
            this.contactbox.TabIndex = 53;
            this.contactbox.Text = "e.g: 03XX-XXXXXXX";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 367);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 27);
            this.label5.TabIndex = 52;
            this.label5.Text = "Contact no:";
            // 
            // l_bloodgroup
            // 
            this.l_bloodgroup.AutoSize = true;
            this.l_bloodgroup.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_bloodgroup.Location = new System.Drawing.Point(40, 556);
            this.l_bloodgroup.Name = "l_bloodgroup";
            this.l_bloodgroup.Size = new System.Drawing.Size(182, 21);
            this.l_bloodgroup.TabIndex = 61;
            this.l_bloodgroup.Text = "Choose blood group";
            this.l_bloodgroup.Visible = false;
            // 
            // underbloodgroup
            // 
            this.underbloodgroup.BackColor = System.Drawing.Color.Gray;
            this.underbloodgroup.Location = new System.Drawing.Point(37, 550);
            this.underbloodgroup.Name = "underbloodgroup";
            this.underbloodgroup.Size = new System.Drawing.Size(400, 3);
            this.underbloodgroup.TabIndex = 59;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(36, 477);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 27);
            this.label8.TabIndex = 57;
            this.label8.Text = "Blood Group:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(610, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(382, 39);
            this.label9.TabIndex = 62;
            this.label9.Text = "Add or Update Donors";
            // 
            // bloodgroupbox
            // 
            this.bloodgroupbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.bloodgroupbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bloodgroupbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bloodgroupbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(181)))), ((int)(((byte)(181)))));
            this.bloodgroupbox.FormattingEnabled = true;
            this.bloodgroupbox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B-",
            "B+",
            "AB-",
            "AB+",
            "O-",
            "O+"});
            this.bloodgroupbox.Location = new System.Drawing.Point(40, 513);
            this.bloodgroupbox.Name = "bloodgroupbox";
            this.bloodgroupbox.Size = new System.Drawing.Size(392, 31);
            this.bloodgroupbox.TabIndex = 63;
            this.bloodgroupbox.Text = "Choose Blood group";
            // 
            // l_email
            // 
            this.l_email.AutoSize = true;
            this.l_email.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_email.Location = new System.Drawing.Point(40, 337);
            this.l_email.Name = "l_email";
            this.l_email.Size = new System.Drawing.Size(167, 21);
            this.l_email.TabIndex = 65;
            this.l_email.Text = "Enter valid email id";
            this.l_email.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(223)))), ((int)(((byte)(188)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(76)))), ((int)(((byte)(81)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(76)))), ((int)(((byte)(81)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeight = 40;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(181)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(76)))), ((int)(((byte)(81)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(223)))), ((int)(((byte)(188)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridView1.Location = new System.Drawing.Point(465, 98);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(181)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(181)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(733, 276);
            this.dataGridView1.TabIndex = 66;
            this.dataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(223)))), ((int)(((byte)(188)))));
            this.dataGridView1.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.dataGridView1.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.dataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(76)))), ((int)(((byte)(81)))));
            this.dataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.dataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dataGridView1.ThemeStyle.HeaderStyle.Height = 40;
            this.dataGridView1.ThemeStyle.ReadOnly = true;
            this.dataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(181)))), ((int)(((byte)(181)))));
            this.dataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.dataGridView1.ThemeStyle.RowsStyle.Height = 30;
            this.dataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            // 
            // chartAp
            // 
            this.chartAp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea1.Name = "ChartArea1";
            this.chartAp.ChartAreas.Add(chartArea1);
            legend1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            legend1.Enabled = false;
            legend1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend1.ForeColor = System.Drawing.Color.Gray;
            legend1.IsTextAutoFit = false;
            legend1.Name = "Legend1";
            this.chartAp.Legends.Add(legend1);
            this.chartAp.Location = new System.Drawing.Point(443, 409);
            this.chartAp.Name = "chartAp";
            this.chartAp.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            series1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series1.IsValueShownAsLabel = true;
            series1.LabelForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartAp.Series.Add(series1);
            this.chartAp.Size = new System.Drawing.Size(199, 168);
            this.chartAp.TabIndex = 67;
            this.chartAp.Text = "chart2";
            this.chartAp.Click += new System.EventHandler(this.chartAp_Click);
            // 
            // chartABp
            // 
            this.chartABp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea2.Name = "ChartArea1";
            this.chartABp.ChartAreas.Add(chartArea2);
            legend2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            legend2.Enabled = false;
            legend2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend2.ForeColor = System.Drawing.Color.Gray;
            legend2.IsTextAutoFit = false;
            legend2.Name = "Legend1";
            this.chartABp.Legends.Add(legend2);
            this.chartABp.Location = new System.Drawing.Point(827, 409);
            this.chartABp.Name = "chartABp";
            this.chartABp.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            series2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series2.IsValueShownAsLabel = true;
            series2.LabelForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chartABp.Series.Add(series2);
            this.chartABp.Size = new System.Drawing.Size(195, 168);
            this.chartABp.TabIndex = 68;
            this.chartABp.Text = "chart1";
            // 
            // chartABn
            // 
            this.chartABn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea3.Name = "ChartArea1";
            this.chartABn.ChartAreas.Add(chartArea3);
            legend3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            legend3.Enabled = false;
            legend3.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend3.ForeColor = System.Drawing.Color.Gray;
            legend3.IsTextAutoFit = false;
            legend3.Name = "Legend1";
            this.chartABn.Legends.Add(legend3);
            this.chartABn.Location = new System.Drawing.Point(1016, 409);
            this.chartABn.Name = "chartABn";
            this.chartABn.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            series3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series3.IsValueShownAsLabel = true;
            series3.LabelForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chartABn.Series.Add(series3);
            this.chartABn.Size = new System.Drawing.Size(191, 168);
            this.chartABn.TabIndex = 69;
            this.chartABn.Text = "chart3";
            // 
            // chartAn
            // 
            this.chartAn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea4.Name = "ChartArea1";
            this.chartAn.ChartAreas.Add(chartArea4);
            legend4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            legend4.Enabled = false;
            legend4.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend4.ForeColor = System.Drawing.Color.Gray;
            legend4.IsTextAutoFit = false;
            legend4.Name = "Legend1";
            this.chartAn.Legends.Add(legend4);
            this.chartAn.Location = new System.Drawing.Point(636, 409);
            this.chartAn.Name = "chartAn";
            this.chartAn.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            series4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series4.IsValueShownAsLabel = true;
            series4.LabelForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chartAn.Series.Add(series4);
            this.chartAn.Size = new System.Drawing.Size(185, 168);
            this.chartAn.TabIndex = 70;
            this.chartAn.Text = "chart4";
            this.chartAn.Click += new System.EventHandler(this.chartAn_Click);
            // 
            // chartBn
            // 
            this.chartBn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea5.Name = "ChartArea1";
            this.chartBn.ChartAreas.Add(chartArea5);
            legend5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            legend5.Enabled = false;
            legend5.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend5.ForeColor = System.Drawing.Color.Gray;
            legend5.IsTextAutoFit = false;
            legend5.Name = "Legend1";
            this.chartBn.Legends.Add(legend5);
            this.chartBn.Location = new System.Drawing.Point(636, 572);
            this.chartBn.Name = "chartBn";
            this.chartBn.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series5.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            series5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series5.IsValueShownAsLabel = true;
            series5.LabelForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.chartBn.Series.Add(series5);
            this.chartBn.Size = new System.Drawing.Size(185, 168);
            this.chartBn.TabIndex = 74;
            this.chartBn.Text = "chart4";
            // 
            // chartOn
            // 
            this.chartOn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea6.Name = "ChartArea1";
            this.chartOn.ChartAreas.Add(chartArea6);
            legend6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            legend6.Enabled = false;
            legend6.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend6.ForeColor = System.Drawing.Color.Gray;
            legend6.IsTextAutoFit = false;
            legend6.Name = "Legend1";
            this.chartOn.Legends.Add(legend6);
            this.chartOn.Location = new System.Drawing.Point(1016, 572);
            this.chartOn.Name = "chartOn";
            this.chartOn.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series6.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            series6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series6.IsValueShownAsLabel = true;
            series6.LabelForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.chartOn.Series.Add(series6);
            this.chartOn.Size = new System.Drawing.Size(191, 168);
            this.chartOn.TabIndex = 73;
            this.chartOn.Text = "chart3";
            // 
            // chartOp
            // 
            this.chartOp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea7.Name = "ChartArea1";
            this.chartOp.ChartAreas.Add(chartArea7);
            legend7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            legend7.Enabled = false;
            legend7.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend7.ForeColor = System.Drawing.Color.Gray;
            legend7.IsTextAutoFit = false;
            legend7.Name = "Legend1";
            this.chartOp.Legends.Add(legend7);
            this.chartOp.Location = new System.Drawing.Point(827, 572);
            this.chartOp.Name = "chartOp";
            this.chartOp.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series7.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            series7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series7.IsValueShownAsLabel = true;
            series7.LabelForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series7.Legend = "Legend1";
            series7.Name = "Series1";
            this.chartOp.Series.Add(series7);
            this.chartOp.Size = new System.Drawing.Size(195, 168);
            this.chartOp.TabIndex = 72;
            this.chartOp.Text = "chart1";
            // 
            // chartBp
            // 
            this.chartBp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            chartArea8.Name = "ChartArea1";
            this.chartBp.ChartAreas.Add(chartArea8);
            legend8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            legend8.Enabled = false;
            legend8.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend8.ForeColor = System.Drawing.Color.Gray;
            legend8.IsTextAutoFit = false;
            legend8.Name = "Legend1";
            this.chartBp.Legends.Add(legend8);
            this.chartBp.Location = new System.Drawing.Point(443, 572);
            this.chartBp.Name = "chartBp";
            this.chartBp.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series8.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            series8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series8.IsValueShownAsLabel = true;
            series8.LabelForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            series8.Legend = "Legend1";
            series8.Name = "Series1";
            this.chartBp.Series.Add(series8);
            this.chartBp.Size = new System.Drawing.Size(199, 168);
            this.chartBp.TabIndex = 71;
            this.chartBp.Text = "chart2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(527, 481);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 23);
            this.label1.TabIndex = 75;
            this.label1.Text = "A+";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(907, 643);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 23);
            this.label6.TabIndex = 76;
            this.label6.Text = "O+";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(710, 643);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 23);
            this.label7.TabIndex = 77;
            this.label7.Text = "B-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(527, 643);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 23);
            this.label10.TabIndex = 78;
            this.label10.Text = "B+";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gray;
            this.label11.Location = new System.Drawing.Point(1094, 481);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 23);
            this.label11.TabIndex = 79;
            this.label11.Text = "AB-";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gray;
            this.label12.Location = new System.Drawing.Point(907, 480);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 23);
            this.label12.TabIndex = 80;
            this.label12.Text = "AB+";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gray;
            this.label13.Location = new System.Drawing.Point(710, 481);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 23);
            this.label13.TabIndex = 81;
            this.label13.Text = "A-";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gray;
            this.label14.Location = new System.Drawing.Point(1094, 643);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 23);
            this.label14.TabIndex = 82;
            this.label14.Text = "O-";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(154, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(135, 104);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 64;
            this.pictureBox1.TabStop = false;
            // 
            // updatedonorbtn
            // 
            this.updatedonorbtn.AutoEllipsis = true;
            this.updatedonorbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.updatedonorbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.updatedonorbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.updatedonorbtn.FlatAppearance.BorderSize = 3;
            this.updatedonorbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updatedonorbtn.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatedonorbtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(223)))), ((int)(((byte)(188)))));
            this.updatedonorbtn.Image = ((System.Drawing.Image)(resources.GetObject("updatedonorbtn.Image")));
            this.updatedonorbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.updatedonorbtn.Location = new System.Drawing.Point(242, 623);
            this.updatedonorbtn.Name = "updatedonorbtn";
            this.updatedonorbtn.Size = new System.Drawing.Size(195, 55);
            this.updatedonorbtn.TabIndex = 51;
            this.updatedonorbtn.Text = "    Update";
            this.updatedonorbtn.UseVisualStyleBackColor = false;
            this.updatedonorbtn.Click += new System.EventHandler(this.updatedonorbtn_Click);
            // 
            // adddonorbtn
            // 
            this.adddonorbtn.AutoEllipsis = true;
            this.adddonorbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.adddonorbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.adddonorbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adddonorbtn.FlatAppearance.BorderSize = 3;
            this.adddonorbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adddonorbtn.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adddonorbtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(181)))), ((int)(((byte)(181)))));
            this.adddonorbtn.Image = ((System.Drawing.Image)(resources.GetObject("adddonorbtn.Image")));
            this.adddonorbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.adddonorbtn.Location = new System.Drawing.Point(33, 623);
            this.adddonorbtn.Name = "adddonorbtn";
            this.adddonorbtn.Size = new System.Drawing.Size(189, 55);
            this.adddonorbtn.TabIndex = 45;
            this.adddonorbtn.Text = "Add";
            this.adddonorbtn.UseVisualStyleBackColor = false;
            this.adddonorbtn.Click += new System.EventHandler(this.adddonorbtn_Click);
            // 
            // donors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chartBn);
            this.Controls.Add(this.chartOn);
            this.Controls.Add(this.chartOp);
            this.Controls.Add(this.chartBp);
            this.Controls.Add(this.chartAn);
            this.Controls.Add(this.chartABn);
            this.Controls.Add(this.chartABp);
            this.Controls.Add(this.chartAp);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.l_email);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bloodgroupbox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.l_bloodgroup);
            this.Controls.Add(this.underbloodgroup);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.l_contact);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.undercontact);
            this.Controls.Add(this.contactbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.updatedonorbtn);
            this.Controls.Add(this.l_wrongusername);
            this.Controls.Add(this.l_emptyname);
            this.Controls.Add(this.adddonorbtn);
            this.Controls.Add(this.underpassword);
            this.Controls.Add(this.login_passwordtxtbox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.underusername);
            this.Controls.Add(this.login_username);
            this.Controls.Add(this.label2);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(76)))), ((int)(((byte)(81)))));
            this.Name = "donors";
            this.Size = new System.Drawing.Size(1207, 763);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartABp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartABn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartBn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartOn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartOp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartBp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label l_wrongusername;
        private System.Windows.Forms.Label l_emptyname;
        private System.Windows.Forms.Button adddonorbtn;
        private System.Windows.Forms.Panel underpassword;
        private System.Windows.Forms.TextBox login_passwordtxtbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel underusername;
        private System.Windows.Forms.TextBox login_username;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button updatedonorbtn;
        private System.Windows.Forms.Label l_contact;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel undercontact;
        private System.Windows.Forms.TextBox contactbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label l_bloodgroup;
        private System.Windows.Forms.Panel underbloodgroup;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox bloodgroupbox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label l_email;
        private Guna.UI2.WinForms.Guna2DataGridView dataGridView1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAp;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartABp;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartABn;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAn;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartBn;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartOn;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartOp;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartBp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
    }
}
