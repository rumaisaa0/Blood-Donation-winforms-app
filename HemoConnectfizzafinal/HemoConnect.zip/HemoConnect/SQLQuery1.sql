﻿insert into threshold(bloodgroup,minquantity)
values('A+',5.5),
('B+',5.5),
('AB+',5.5),
('O+',5.5),
('A-',5.5),
('B-',5.5),
('AB-',5.5),
('O-',5.5);

select * from threshold